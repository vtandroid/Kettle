<?php
echo "<h1>Hello</h1>";
shell_exec("rm -rf x.out; rm -rf y.out;");
echo shell_exec("./kettleRun.sh restart");

?>
