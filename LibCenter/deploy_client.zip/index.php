<?php
echo "<h1>Hello</h1>";
echo shell_exec("./kettleRun.sh start");
?>
